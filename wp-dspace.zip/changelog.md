# Historial de cambios de versión

## **Versión 2.2** (08/2023)

- Autocompletado de fechas
- Recuperación de fechas faltantes
- Paginación en consultas vía API
- Corrección de errores

## **Versión 2.0**

- Integración con API Dspace 7
<?php
/**
 * Description of Sedici-config
 *
 * @author Paula Salamone
 */
define ( 'S_CONECTOR2', '%5C' );
define ( 'S_CONECTOR3', '%7C' );
define ('S_CONECTOR4' , '%2C');
define ('S_CONECTOR5', '\+');
define ('S_SEPARATOR', '\|\|\|');
class Sedici_config {
//put your code here
}

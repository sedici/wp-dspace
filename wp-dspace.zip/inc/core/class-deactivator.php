<?php

namespace Wp_dspace\Inc\Core;

/**
 * Acciones luego de desactivar el plugin
 * @author     Sedici-Manzur Ezequiel
 */

class Deactivator {

	/**
	 *
	 */
	public static function deactivate() {

	}

}

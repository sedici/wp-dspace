<h1>Repositorios</h1>
<div id="notice_result"></div>
<table class="form-table">
    <thead>
        <tr >
            <th scope='row'>Nombre</th>
            <th scope='row'>Url</th>
            <th scope='row'></th>
            <th scope='row'></th>
        </tr>
    </thead>
    <tbody id="list_repo">
    </tbody>
    <tfoot >
        <tr>
            <td colspan="4" style="text-align:right" ><button class="button button-primary agregar-nuevo-repo"> Agregar nuevo repositorio</button></td>
        </tr>
  </tfoot>
</table>
<hr>
<div id="form-repo" >
    
</div>
